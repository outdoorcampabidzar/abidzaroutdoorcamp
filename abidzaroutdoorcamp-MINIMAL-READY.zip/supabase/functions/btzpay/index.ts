import BetabotzPaygate from "npm:betabotz-paygate@1.0.1";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const apiKey = Deno.env.get("BTZPAY_API_KEY") || "";
const apiKeySale = Deno.env.get("BTZPAY_API_KEY_SALE") || "";
const apiKeyRental = Deno.env.get("BTZPAY_API_KEY_RENTAL") || "";
const publicSiteUrl = (Deno.env.get("PUBLIC_SITE_URL") || "").replace(/\/$/, "");
const admin = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

function gatewayStatus(value: unknown) {
  const s = String(value || "pending").toLowerCase();
  if (["sukses", "success", "paid", "settlement", "completed"].includes(s)) return "paid";
  if (["cancel", "cancelled", "canceled"].includes(s)) return "cancelled";
  if (["expired", "kadaluarsa", "kadaluarsa"].includes(s)) return "expired";
  if (["gagal", "failed", "failure"].includes(s)) return "failed";
  if (s === "refunded") return "refunded";
  return "pending";
}

function createPaygate(key: string) {
  if (!key) throw new Error("API key BTZPay belum dikonfigurasi");
  return new BetabotzPaygate({ apiKey: key, endpoint: "https://pay.betabotz.eu.org/api" });
}

function unwrapPayment(value: any): any {
  return value?.data?.payment || value?.data || value?.payment || value || {};
}

function gatewayId(value: any): string {
  const x = unwrapPayment(value);
  return String(x.id ?? x.transaction_id ?? x.transactionId ?? x.payment_id ?? x.reference_id ?? "");
}
function paymentUrl(value: any): string | null {
  const x = unwrapPayment(value);
  return x.payment_url ?? x.paymentUrl ?? x.url ?? x.checkout_url ?? null;
}
function paymentExpiry(value: any, minutes: number): string {
  const x = unwrapPayment(value);
  const raw = x.expires_at ?? x.expired_at ?? x.expiredAt ?? x.expiry;
  if (raw) {
    const d = new Date(raw);
    if (!Number.isNaN(d.getTime())) return d.toISOString();
  }
  return new Date(Date.now() + minutes * 60_000).toISOString();
}

async function authenticatedUser(req: Request) {
  const authorization = req.headers.get("Authorization") || "";
  const client = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authorization } }, auth: { persistSession: false } });
  const { data: { user } } = await client.auth.getUser();
  if (!user) throw new Error("Silakan login terlebih dahulu");
  return user;
}

async function getOrder(orderId: string, userId: string, allowAdmin = false) {
  const { data: order, error } = await admin.from("orders").select("*").eq("id", orderId).single();
  if (error || !order) throw new Error("Pesanan tidak ditemukan");
  if (order.user_id !== userId && !allowAdmin) throw new Error("Akses ditolak");
  return order;
}

async function paymentModeForOrder(orderId: string) {
  const { data: lines, error } = await admin.from("order_items").select("item_type,fulfillment_type").eq("order_id", orderId);
  if (error) throw error;
  const modes = new Set((lines || []).filter(x => x.item_type === "product").map(x => String(x.fulfillment_type || "rental").toLowerCase()));
  if (modes.has("sale") && modes.has("rental")) throw new Error("Pesanan tidak boleh mencampur mode Jual dan Sewa");
  return modes.has("sale") ? "sale" : "rental";
}

async function settings() {
  const { data, error } = await admin.from("site_settings").select("settings").eq("id", "main").single();
  if (error) throw error;
  return data?.settings || {};
}

function keyForMode(mode: string) { return mode === "sale" ? (apiKeySale || apiKey) : (apiKeyRental || apiKey); }

async function createPayment(orderId: string, userId: string, allowAdmin = false) {
  if (!publicSiteUrl) throw new Error("Secret PUBLIC_SITE_URL belum dipasang");
  const order = await getOrder(orderId, userId, allowAdmin);
  if (["paid", "completed"].includes(order.status) || order.payment_status === "paid") throw new Error("Pesanan sudah dibayar");
  const mode = await paymentModeForOrder(orderId);
  const cfg = await settings();
  if (!cfg.payment_enabled) throw new Error("Pembayaran otomatis sedang dinonaktifkan");

  const minutes = Math.min(60, Math.max(5, Number(cfg.payment_timeout_minutes) || 15));
  const method = mode === "sale" ? (cfg.payment_method_sale || cfg.payment_method || "qrisdana") : (cfg.payment_method_rental || cfg.payment_method || "qrisorkut");
  const paygate = createPaygate(keyForMode(mode));
  const callbackUrl = `${publicSiteUrl}/functions/v1/btzpay`;
  const returnUrl = `${publicSiteUrl}/payment.html?order=${encodeURIComponent(orderId)}`;
  const total = Number(order.total ?? order.total_amount ?? 0);
  if (!Number.isFinite(total) || total < 0) throw new Error("Total pesanan tidak valid");

  const raw = await paygate.createPayment({
    ref_id: orderId,
    amount: total,
    payer_email: order.customer_email || "noreply@abidzaroutdoor.id",
    payer_name: order.customer_name || "Customer",
    payer_phone: order.phone || "08000000000",
    callback: callbackUrl,
    return_url: returnUrl,
    expired: minutes,
    note: `Pembayaran ${order.order_number || orderId} · ${method}`,
  });
  const id = gatewayId(raw);
  if (!id) throw new Error("BTZPay tidak mengembalikan ID transaksi");
  const expires = paymentExpiry(raw, minutes);
  const url = paymentUrl(raw);

  const { data: existing } = await admin.from("payment_transactions").select("id").eq("gateway_transaction_id", id).maybeSingle();
  let row;
  if (existing?.id) {
    const { data, error } = await admin.from("payment_transactions").update({ payment_method: method, amount: total, total_amount: total, payment_url: url, expires_at: expires, raw_response: raw, updated_at: new Date().toISOString() }).eq("id", existing.id).select("*").single();
    if (error) throw error; row = data;
  } else {
    const { data, error } = await admin.from("payment_transactions").insert({ order_id: orderId, gateway: "btzpay", gateway_transaction_id: id, payment_method: method, amount: total, total_amount: total, status: "pending", payment_url: url, expires_at: expires, raw_response: raw }).select("*").single();
    if (error) throw error; row = data;
  }
  return row;
}

async function applyStatus(paymentId: string, status: string, raw: any = {}, reason: string | null = null) {
  const { data: payment, error } = await admin.from("payment_transactions").select("*").eq("id", paymentId).single();
  if (error || !payment) throw new Error("Transaksi pembayaran tidak ditemukan");
  const { error: rpcError } = await admin.rpc("apply_btzpay_status", { p_transaction_id: payment.gateway_transaction_id, p_status: status, p_raw: raw, p_reason: reason });
  if (rpcError) throw rpcError;
  const { data: updated } = await admin.from("payment_transactions").select("*").eq("id", paymentId).single();
  return updated;
}

async function syncPayment(orderId: string, userId: string, allowAdmin = false) {
  const order = await getOrder(orderId, userId, allowAdmin);
  const { data: payment, error } = await admin.from("payment_transactions").select("*").eq("order_id", orderId).order("created_at", { ascending: false }).limit(1).single();
  if (error || !payment) throw new Error("Data pembayaran tidak ditemukan");
  const paygate = createPaygate(keyForMode(await paymentModeForOrder(orderId)));
  const raw = await paygate.getPaymentStatus(payment.gateway_transaction_id);
  const status = gatewayStatus(raw?.status ?? raw?.data?.status);
  return applyStatus(payment.id, status, raw);
}

async function cancelPayment(orderId: string, userId: string) {
  const order = await getOrder(orderId, userId);
  const { data: payment, error } = await admin.from("payment_transactions").select("*").eq("order_id", orderId).order("created_at", { ascending: false }).limit(1).single();
  if (error || !payment) throw new Error("Data pembayaran tidak ditemukan");
  const paygate = createPaygate(keyForMode(await paymentModeForOrder(orderId)));
  try { await paygate.cancelPayment(payment.gateway_transaction_id); } catch (_) { /* status below remains authoritative */ }
  return applyStatus(payment.id, "cancelled", { source: "customer_cancel" });
}

async function handleWebhook(req: Request) {
  const body = await req.json();
  const txId = String(body.transaction_id ?? body.transactionId ?? body.payment_id ?? body.id ?? body.gateway_transaction_id ?? "");
  const refId = String(body.ref_id ?? body.reference_id ?? "");
  let payment: any = null;
  if (txId) {
    const { data } = await admin.from("payment_transactions").select("*").eq("gateway_transaction_id", txId).maybeSingle(); payment = data;
  }
  if (!payment && refId) {
    const { data } = await admin.from("payment_transactions").select("*").eq("order_id", refId).eq("status", "pending").order("created_at", { ascending: false }).limit(1).maybeSingle(); payment = data;
  }
  if (!payment) return json({ success: false, error: "Transaksi tidak ditemukan" }, 404);

  let raw: any = body;
  try {
    const order = await getOrder(payment.order_id, "service-webhook", true);
    const mode = await paymentModeForOrder(order.id);
    const paygate = createPaygate(keyForMode(mode));
    raw = await paygate.getPaymentStatus(payment.gateway_transaction_id);
  } catch (_) {
    // Never mark paid from an unverified callback.
    return json({ success: false, error: "Status gateway belum dapat diverifikasi" }, 409);
  }
  const status = gatewayStatus(raw?.status ?? raw?.data?.status);
  await applyStatus(payment.id, status, raw);
  await admin.from("payment_webhook_logs").insert({ gateway_transaction_id: payment.gateway_transaction_id, event_status: status, payload: body, verified: true });
  return json({ success: true, status });
}

async function checkExpiry() {
  const now = new Date().toISOString();
  const { data: rows } = await admin.from("payment_transactions").select("*").eq("status", "pending").lt("expires_at", now).limit(100);
  for (const payment of rows || []) {
    try {
      const order = await getOrder(payment.order_id, "cron", true);
      const paygate = createPaygate(keyForMode(await paymentModeForOrder(order.id)));
      try { await paygate.cancelPayment(payment.gateway_transaction_id); } catch (_) {}
      await applyStatus(payment.id, "expired", { source: "cron" });
    } catch (e) {
      console.error("expire payment", payment.id, e);
    }
  }
  return json({ success: true, expired: rows?.length || 0 });
}

export default async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = new URL(req.url);
    const path = url.pathname.replace(/^.*\/btzpay/, "") || "/";
    if (path === "/" && req.method === "POST") {
      const body = await req.json();
      const action = String(body.action || "");
      if (action === "webhook") return await handleWebhook(new Request(req.url, { method: "POST", body: JSON.stringify(body) }));
      if (action === "expire") { if (req.headers.get("x-cron-secret") !== Deno.env.get("BTZPAY_CRON_SECRET")) return json({ success: false, error: "Unauthorized" }, 401); return await checkExpiry(); }
      const user = await authenticatedUser(req);
      if (action === "create") return json({ success: true, payment: await createPayment(body.order_id, user.id) });
      if (action === "recreate") return json({ success: true, payment: await createPayment(body.order_id, user.id) });
      if (action === "check") {
        let orderId = body.order_id;
        if (!orderId && body.payment_id) {
          const { data: p } = await admin.from("payment_transactions").select("order_id").eq("id", body.payment_id).single();
          orderId = p?.order_id;
        }
        if (!orderId) throw new Error("ID pembayaran tidak valid");
        return json({ success: true, payment: await syncPayment(orderId, user.id) });
      }
      if (action === "cancel") return json({ success: true, payment: await cancelPayment(body.order_id, user.id) });
      if (action === "sync") return json({ success: true, payment: await syncPayment(body.order_id, user.id) });
      return json({ success: false, error: "Aksi pembayaran tidak dikenal" }, 400);
    }
    if (path === "/webhook" && req.method === "POST") return await handleWebhook(req);
    if (path === "/check-expiry" && req.method === "GET") {
      if (req.headers.get("x-cron-secret") !== Deno.env.get("BTZPAY_CRON_SECRET")) return json({ success: false, error: "Unauthorized" }, 401);
      return await checkExpiry();
    }
    return json({ success: false, error: "Endpoint tidak ditemukan" }, 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ success: false, error: message }, 400);
  }
};
