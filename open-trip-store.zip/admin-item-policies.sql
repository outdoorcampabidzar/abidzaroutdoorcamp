-- Jalankan di Supabase SQL Editor bila form admin mendapat error RLS/permission.

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and lower(trim(role)) = 'admin'
  );
$$;

alter table public.items enable row level security;

drop policy if exists "items public read active" on public.items;
create policy "items public read active"
on public.items for select
using (is_active = true or public.is_admin());

drop policy if exists "items admin insert" on public.items;
create policy "items admin insert"
on public.items for insert
to authenticated
with check (public.is_admin());

drop policy if exists "items admin update" on public.items;
create policy "items admin update"
on public.items for update
to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "items admin delete" on public.items;
create policy "items admin delete"
on public.items for delete
to authenticated
using (public.is_admin());

grant select on public.items to anon, authenticated;
grant insert, update, delete on public.items to authenticated;
grant execute on function public.is_admin() to authenticated;
