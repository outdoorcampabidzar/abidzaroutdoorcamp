-- PENGELOLAAN ADMIN ABIDZAROUTDOORCAMP
-- Jalankan seluruh file ini melalui Supabase SQL Editor.

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid()
      and lower(trim(role)) = 'admin'
  );
$$;

create or replace function public.list_admin_users()
returns table (
  user_id uuid,
  email text,
  full_name text,
  created_at timestamptz,
  admin_since timestamptz
)
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if not public.is_admin() then
    raise exception 'Akses administrator diperlukan';
  end if;

  return query
  select
    u.id as user_id,
    u.email::text as email,
    p.full_name::text as full_name,
    u.created_at,
    p.created_at as admin_since
  from auth.users u
  join public.profiles p on p.id = u.id
  where lower(trim(p.role)) = 'admin'
  order by
    case when u.id = auth.uid() then 0 else 1 end,
    lower(u.email);
end;
$$;

create or replace function public.add_admin_by_email(
  p_email text,
  p_full_name text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_user_id uuid;
  v_email text;
begin
  if not public.is_admin() then
    raise exception 'Akses administrator diperlukan';
  end if;

  v_email := lower(trim(coalesce(p_email, '')));

  if v_email = '' then
    raise exception 'Email wajib diisi';
  end if;

  select id
  into v_user_id
  from auth.users
  where lower(email) = v_email
  limit 1;

  if v_user_id is null then
    raise exception
      'Pengguna dengan email % belum terdaftar. Minta pengguna mendaftar terlebih dahulu.',
      v_email;
  end if;

  insert into public.profiles (
    id,
    full_name,
    role
  )
  values (
    v_user_id,
    nullif(trim(p_full_name), ''),
    'admin'
  )
  on conflict (id) do update
  set
    role = 'admin',
    full_name = coalesce(
      nullif(trim(excluded.full_name), ''),
      public.profiles.full_name
    );

  return jsonb_build_object(
    'user_id', v_user_id,
    'email', v_email,
    'role', 'admin'
  );
end;
$$;

create or replace function public.remove_admin_access(
  p_user_id uuid
)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_admin_count integer;
  v_target_is_admin boolean;
begin
  if not public.is_admin() then
    raise exception 'Akses administrator diperlukan';
  end if;

  if p_user_id is null then
    raise exception 'Pengguna tidak valid';
  end if;

  if p_user_id = auth.uid() then
    raise exception 'Anda tidak dapat mencabut akses admin akun sendiri';
  end if;

  select exists (
    select 1
    from public.profiles
    where id = p_user_id
      and lower(trim(role)) = 'admin'
  )
  into v_target_is_admin;

  if not v_target_is_admin then
    raise exception 'Pengguna tersebut bukan administrator';
  end if;

  select count(*)
  into v_admin_count
  from public.profiles
  where lower(trim(role)) = 'admin';

  if v_admin_count <= 1 then
    raise exception 'Administrator terakhir tidak dapat dihapus';
  end if;

  update public.profiles
  set role = 'user'
  where id = p_user_id;
end;
$$;

revoke all on function public.list_admin_users() from public;
revoke all on function public.add_admin_by_email(text, text) from public;
revoke all on function public.remove_admin_access(uuid) from public;

grant execute on function public.is_admin() to authenticated;
grant execute on function public.list_admin_users() to authenticated;
grant execute on function public.add_admin_by_email(text, text) to authenticated;
grant execute on function public.remove_admin_access(uuid) to authenticated;
