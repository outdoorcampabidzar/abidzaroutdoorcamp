-- OPSIONAL: PERIKSA HASIL KOMENTAR
-- Jalankan setelah menyimpan komentar melalui website.

select
  score,
  comment,
  char_length(coalesce(comment, '')) as comment_length,
  updated_at
from public.website_ratings
order by updated_at desc;
