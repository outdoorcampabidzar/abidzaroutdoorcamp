-- TAMPILKAN KOMENTAR RATING WEBSITE
-- Jalankan seluruh file melalui Supabase SQL Editor.

create table if not exists public.website_ratings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  score integer not null check (score between 1 and 5),
  comment text check (
    comment is null or char_length(comment) <= 300
  ),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id)
);

create or replace function public.get_website_rating()
returns jsonb
language plpgsql
stable
security definer
set search_path = public, auth
as $$
declare
  v_average numeric := 0;
  v_count bigint := 0;
  v_my_score integer := 0;
  v_my_comment text := '';
begin
  select
    coalesce(round(avg(wr.score)::numeric, 1), 0),
    count(*)
  into
    v_average,
    v_count
  from public.website_ratings wr;

  if auth.uid() is not null then
    select
      wr.score,
      coalesce(wr.comment, '')
    into
      v_my_score,
      v_my_comment
    from public.website_ratings wr
    where wr.user_id = auth.uid()
    limit 1;

    v_my_score := coalesce(v_my_score, 0);
    v_my_comment := coalesce(v_my_comment, '');
  end if;

  return jsonb_build_object(
    'rating_average', v_average,
    'rating_count', v_count,
    'my_score', v_my_score,
    'my_comment', v_my_comment
  );
end;
$$;

create or replace function public.submit_website_rating(
  p_score integer,
  p_comment text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_user_id uuid := auth.uid();
  v_comment text;
  v_average numeric := 0;
  v_count bigint := 0;
begin
  if v_user_id is null then
    raise exception 'Silakan login untuk memberikan rating website';
  end if;

  if p_score is null or p_score < 1 or p_score > 5 then
    raise exception 'Rating harus antara 1 sampai 5 bintang';
  end if;

  v_comment := nullif(trim(coalesce(p_comment, '')), '');

  if v_comment is not null and char_length(v_comment) > 300 then
    raise exception 'Komentar maksimal 300 karakter';
  end if;

  insert into public.website_ratings (
    user_id,
    score,
    comment,
    updated_at
  )
  values (
    v_user_id,
    p_score,
    v_comment,
    now()
  )
  on conflict (user_id)
  do update set
    score = excluded.score,
    comment = excluded.comment,
    updated_at = now();

  select
    coalesce(round(avg(wr.score)::numeric, 1), 0),
    count(*)
  into
    v_average,
    v_count
  from public.website_ratings wr;

  return jsonb_build_object(
    'rating_average', v_average,
    'rating_count', v_count,
    'my_score', p_score,
    'my_comment', coalesce(v_comment, '')
  );
end;
$$;

-- Daftar komentar publik. Email dan user_id tidak pernah dikirim ke browser.
create or replace function public.get_website_reviews(
  p_limit integer default 6
)
returns table (
  display_name text,
  score integer,
  comment text,
  created_at timestamptz,
  updated_at timestamptz,
  is_mine boolean,
  total_count bigint
)
language sql
stable
security definer
set search_path = public, auth
as $$
  with public_reviews as (
    select
      case
        when nullif(trim(coalesce(p.full_name, '')), '') is not null
          then split_part(trim(p.full_name), ' ', 1)
        else 'Pengguna'
      end::text as display_name,
      wr.score,
      wr.comment,
      wr.created_at,
      wr.updated_at,
      (wr.user_id = auth.uid()) as is_mine,
      count(*) over () as total_count
    from public.website_ratings wr
    left join public.profiles p on p.id = wr.user_id
    where nullif(trim(coalesce(wr.comment, '')), '') is not null
    order by
      case when wr.user_id = auth.uid() then 0 else 1 end,
      wr.updated_at desc
  )
  select *
  from public_reviews
  limit greatest(1, least(coalesce(p_limit, 6), 30));
$$;

revoke all on table public.website_ratings from anon, authenticated;
revoke all on function public.get_website_rating() from public;
revoke all on function public.submit_website_rating(integer, text) from public;
revoke all on function public.get_website_reviews(integer) from public;

grant usage on schema public to anon, authenticated;

grant execute on function public.get_website_rating()
to anon, authenticated;

grant execute on function public.submit_website_rating(integer, text)
to authenticated;

grant execute on function public.get_website_reviews(integer)
to anon, authenticated;

notify pgrst, 'reload schema';

select
  p.proname as function_name,
  pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in (
    'get_website_rating',
    'submit_website_rating',
    'get_website_reviews'
  )
order by p.proname;
