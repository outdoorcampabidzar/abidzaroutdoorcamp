-- PATCH PREFIX NOMOR PESANAN MENJADI AOC
-- Jalankan seluruh file ini di Supabase SQL Editor.

create or replace function public.create_order(p_customer jsonb,p_items jsonb,p_voucher_code text default null,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public,auth as $$
declare uid uuid:=auth.uid(); email text:=coalesce(auth.jwt()->>'email',''); oid uuid; ono text; j jsonb; it public.items%rowtype; iid uuid; q int; sub numeric:=0; disc numeric:=0; tot numeric:=0; vc text:=nullif(upper(trim(coalesce(p_voucher_code,''))),''); v public.vouchers%rowtype; need_g boolean:=false;
begin
 if uid is null then raise exception 'Silakan login terlebih dahulu'; end if;
 if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Keranjang kosong'; end if;
 if nullif(trim(p_customer->>'full_name'),'') is null or nullif(trim(p_customer->>'phone'),'') is null or nullif(trim(p_customer->>'address'),'') is null or nullif(trim(p_customer->>'city'),'') is null or nullif(trim(p_customer->>'identity_type'),'') is null or char_length(trim(coalesce(p_customer->>'identity_last4','')))<>4 or nullif(trim(p_customer->>'emergency_contact_name'),'') is null or nullif(trim(p_customer->>'emergency_contact_phone'),'') is null then raise exception 'Identitas belum lengkap'; end if;
 for j in select value from jsonb_array_elements(p_items) loop
  iid:=(j->>'item_id')::uuid; q:=(j->>'quantity')::int;
  select * into it from public.items where id=iid and is_active=true;
  if not found then raise exception 'Salah satu item tidak tersedia'; end if;
  if q<1 or q>99 then raise exception 'Jumlah item tidak valid'; end if;
  if it.type='product' and it.stock<q then raise exception 'Stok % tidak cukup',it.title; end if;
  if it.type='trip' and coalesce(it.quota,0)<q then raise exception 'Kuota % tidak cukup',it.title; end if;
  sub:=sub+(it.price*q); need_g:=need_g or it.requires_guarantee;
 end loop;
 if need_g and (nullif(trim(p_customer->>'guarantee_type'),'') is null or nullif(trim(p_customer->>'guarantee_notes'),'') is null) then raise exception 'Pesanan ini memerlukan jaminan'; end if;
 if vc is not null then
  select * into v from public.vouchers where code=vc and is_active=true and now() between starts_at and expires_at and used_count<quota;
  if not found then raise exception 'Voucher tidak valid atau kuota habis'; end if;
  if sub<v.min_purchase then raise exception 'Minimal pembelian voucher adalah %',v.min_purchase; end if;
  disc:=case when v.discount_type='percent' then sub*(v.discount_value/100) else v.discount_value end;
  if v.max_discount is not null then disc:=least(disc,v.max_discount); end if;
  disc:=least(greatest(disc,0),sub);
 end if;
 tot:=sub-disc; ono:='AOC-'||to_char(clock_timestamp(),'YYYYMMDD')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
 insert into public.orders(order_number,user_id,customer_name,customer_email,phone,address,city,postal_code,identity_type,identity_last4,emergency_contact_name,emergency_contact_phone,guarantee_type,guarantee_notes,customer_notes,voucher_code,subtotal,discount,total)
 values(ono,uid,trim(p_customer->>'full_name'),email,trim(p_customer->>'phone'),trim(p_customer->>'address'),trim(p_customer->>'city'),nullif(trim(p_customer->>'postal_code'),''),trim(p_customer->>'identity_type'),trim(p_customer->>'identity_last4'),trim(p_customer->>'emergency_contact_name'),trim(p_customer->>'emergency_contact_phone'),nullif(trim(p_customer->>'guarantee_type'),''),nullif(trim(p_customer->>'guarantee_notes'),''),nullif(trim(p_notes),''),vc,sub,disc,tot) returning id into oid;
 for j in select value from jsonb_array_elements(p_items) loop
  iid:=(j->>'item_id')::uuid; q:=(j->>'quantity')::int; select * into it from public.items where id=iid;
  insert into public.order_items(order_id,item_id,title_snapshot,item_type,price_snapshot,quantity,line_total,trip_date_snapshot) values(oid,it.id,it.title,it.type,it.price,q,it.price*q,it.trip_date);
 end loop;
 update public.profiles set full_name=trim(p_customer->>'full_name'),phone=trim(p_customer->>'phone'),address=trim(p_customer->>'address'),city=trim(p_customer->>'city'),postal_code=nullif(trim(p_customer->>'postal_code'),'') where id=uid;
 return jsonb_build_object('order_id',oid,'order_number',ono,'subtotal',sub,'discount',disc,'total',tot,'status','pending');
end $$;

-- Opsional: ubah nomor pesanan lama dari ORD- menjadi AOC-.
-- Baris ini aman dijalankan karena hanya mengubah awalan ORD-.
update public.orders
set order_number = regexp_replace(order_number, '^ORD-', 'AOC-')
where order_number like 'ORD-%';
