-- PERBAIKAN FINAL KOMENTAR RATING
-- Menggunakan nama fungsi baru agar tidak memakai cache RPC lama.
-- Jalankan seluruh file ini melalui Supabase SQL Editor.

create or replace function public.save_website_review_v2(
  p_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_user_id uuid := auth.uid();
  v_score integer;
  v_input_comment text;
  v_existing_comment text;
  v_saved_comment text;
  v_average numeric := 0;
  v_count bigint := 0;
begin
  if v_user_id is null then
    raise exception 'Sesi login tidak ditemukan. Silakan login ulang.';
  end if;

  if p_payload is null then
    raise exception 'Data rating tidak ditemukan';
  end if;

  begin
    v_score := (p_payload ->> 'score')::integer;
  exception
    when others then
      raise exception 'Nilai rating tidak valid';
  end;

  if v_score < 1 or v_score > 5 then
    raise exception 'Rating harus antara 1 sampai 5 bintang';
  end if;

  v_input_comment :=
    nullif(trim(coalesce(p_payload ->> 'comment', '')), '');

  if v_input_comment is not null
     and char_length(v_input_comment) > 300 then
    raise exception 'Komentar maksimal 300 karakter';
  end if;

  select wr.comment
  into v_existing_comment
  from public.website_ratings wr
  where wr.user_id = v_user_id
  limit 1;

  -- Komentar baru dipakai bila ada. Input kosong mempertahankan komentar lama.
  v_saved_comment := coalesce(v_input_comment, v_existing_comment);

  insert into public.website_ratings (
    user_id,
    score,
    comment,
    updated_at
  )
  values (
    v_user_id,
    v_score,
    v_saved_comment,
    now()
  )
  on conflict (user_id)
  do update set
    score = excluded.score,
    comment = coalesce(
      excluded.comment,
      public.website_ratings.comment
    ),
    updated_at = now();

  -- Baca ulang nilai sebenarnya dari tabel untuk verifikasi.
  select wr.comment
  into v_saved_comment
  from public.website_ratings wr
  where wr.user_id = v_user_id
  limit 1;

  select
    coalesce(round(avg(wr.score)::numeric, 1), 0),
    count(*)
  into
    v_average,
    v_count
  from public.website_ratings wr;

  return jsonb_build_object(
    'success', true,
    'rating_average', v_average,
    'rating_count', v_count,
    'my_score', v_score,
    'my_comment', coalesce(v_saved_comment, ''),
    'comment_length', char_length(coalesce(v_saved_comment, ''))
  );
end;
$$;

revoke all on function public.save_website_review_v2(jsonb)
from public;

grant execute on function public.save_website_review_v2(jsonb)
to authenticated;

notify pgrst, 'reload schema';

-- Hasil harus menampilkan save_website_review_v2 | p_payload jsonb
select
  p.proname as function_name,
  pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname = 'save_website_review_v2';
