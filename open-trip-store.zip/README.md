# AbidzarOutdoorcamp — Keranjang & Pesanan

## Fitur
- Order langsung per item
- Keranjang untuk berbagai item
- Jumlah unit / peserta
- Identitas pemesan: nama, email, HP, alamat, kota, kode pos
- Jenis identitas + 4 karakter terakhir
- Kontak darurat
- Jenis dan rincian jaminan
- Voucher diproses melalui database
- Harga divalidasi dari database
- Menu Pesanan Saya
- Admin melihat identitas dan mengubah status
- Stok/kuota berkurang ketika pesanan dikonfirmasi

## Instalasi
1. Backup folder website lama.
2. Jalankan `supabase-schema-orders.sql` di Supabase SQL Editor.
3. Salin Project URL, Publishable Key, dan nomor WhatsApp lama ke `config.js`.
4. Upload semua file ke hosting atau jalankan `python -m http.server 8000`.
5. Refresh dengan Ctrl+F5.

## Privasi
Website hanya menyimpan 4 karakter terakhir identitas, bukan nomor lengkap atau foto dokumen. Untuk upload KTP/SIM, gunakan bucket Supabase Storage privat dan kebijakan retensi khusus.

## Format nomor pesanan AOC

Nomor pesanan baru menggunakan format:

```text
AOC-YYYYMMDD-XXXXXX
```

Untuk project Supabase yang sudah berjalan, jalankan `patch-order-prefix-aoc.sql` di SQL Editor. File patch juga dapat mengubah nomor lama berawalan `ORD-` menjadi `AOC-`.


## Katalog terpisah

- `rental.html` — katalog khusus Sewa Item (`items.type = product`)
- `trips.html` — katalog khusus Open Trip (`items.type = trip`)
- `index.html` — halaman depan dan preview kedua katalog
- `catalog.js` — renderer bersama untuk kedua katalog

Tidak ada perubahan database. Nilai internal `product` tetap digunakan agar data lama tetap kompatibel, tetapi pada tampilan disebut **Sewa Item**.


## Pengelolaan Administrator

Jalankan `admin-management.sql` melalui Supabase SQL Editor.

Setelah aktif, Admin Panel memiliki menu **Administrator** untuk:
- memberikan akses admin berdasarkan email pengguna yang sudah terdaftar;
- menampilkan daftar admin;
- mencabut akses admin tanpa menghapus akun;
- mencegah admin mencabut akses akun sendiri;
- mencegah penghapusan administrator terakhir.

Fitur ini tidak membutuhkan dan tidak boleh menggunakan service-role key di browser.


## Rating Website

Rating berlaku untuk keseluruhan website, bukan untuk produk atau open trip.

Jalankan `website-rating.sql` melalui Supabase SQL Editor.

Fitur:
- rating website 1–5 bintang;
- rata-rata dan jumlah penilaian tampil di beranda;
- komentar singkat opsional;
- satu akun satu rating;
- rating lama dapat diperbarui;
- pengguna harus login untuk mengirim penilaian.


## Premium UI Pro

Pembaruan visual menyeluruh tanpa mengubah database atau logika Supabase:
- hero modern;
- kartu katalog premium;
- navbar glass;
- tombol dan form konsisten;
- admin, checkout, pesanan, rating, dan ulasan diperhalus;
- footer baru;
- responsif dan mendukung reduced motion.


## Registrasi Lengkap

Ganti `login.html`, tambahkan `auth.js`, lalu jalankan
`registration-profile.sql` melalui Supabase SQL Editor.

Data registrasi:
- nama lengkap;
- email;
- nomor WhatsApp;
- kota/kabupaten;
- alamat domisili;
- kode pos;
- password dan konfirmasi password.

Metadata profil otomatis disinkronkan ke tabel `profiles` dan dapat dipakai
sebagai isian awal halaman checkout.
