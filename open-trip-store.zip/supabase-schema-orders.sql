create extension if not exists "pgcrypto";

alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists address text;
alter table public.profiles add column if not exists city text;
alter table public.profiles add column if not exists postal_code text;
alter table public.items add column if not exists requires_guarantee boolean not null default false;
alter table public.items add column if not exists guarantee_note text;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  user_id uuid not null references auth.users(id) on delete restrict,
  customer_name text not null,
  customer_email text not null,
  phone text not null,
  address text not null,
  city text not null,
  postal_code text,
  identity_type text not null,
  identity_last4 text not null check (char_length(identity_last4)=4),
  emergency_contact_name text not null,
  emergency_contact_phone text not null,
  guarantee_type text,
  guarantee_notes text,
  customer_notes text,
  admin_notes text,
  voucher_code text,
  subtotal numeric(14,2) not null default 0,
  discount numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  status text not null default 'pending' check(status in('pending','confirmed','paid','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  item_id uuid not null references public.items(id) on delete restrict,
  title_snapshot text not null,
  item_type text not null,
  price_snapshot numeric(14,2) not null,
  quantity integer not null check(quantity>0),
  line_total numeric(14,2) not null,
  trip_date_snapshot date,
  created_at timestamptz not null default now()
);

alter table public.orders enable row level security;
alter table public.order_items enable row level security;

drop policy if exists "orders own or admin read" on public.orders;
create policy "orders own or admin read" on public.orders for select using(user_id=auth.uid() or public.is_admin());
drop policy if exists "orders admin update" on public.orders;
create policy "orders admin update" on public.orders for update using(public.is_admin()) with check(public.is_admin());
drop policy if exists "order items own or admin read" on public.order_items;
create policy "order items own or admin read" on public.order_items for select using(exists(select 1 from public.orders o where o.id=order_items.order_id and (o.user_id=auth.uid() or public.is_admin())));
drop policy if exists "profiles own update" on public.profiles;
create policy "profiles own update" on public.profiles for update using(id=auth.uid()) with check(id=auth.uid());

drop policy if exists "vouchers active read" on public.vouchers;
drop policy if exists "vouchers admin read" on public.vouchers;
create policy "vouchers admin read" on public.vouchers for select using(public.is_admin());

create or replace function public.preview_voucher(p_code text,p_subtotal numeric)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v public.vouchers%rowtype; d numeric:=0; c text:=upper(trim(coalesce(p_code,'')));
begin
 if auth.uid() is null then raise exception 'Silakan login terlebih dahulu'; end if;
 select * into v from public.vouchers where code=c and is_active=true and now() between starts_at and expires_at and used_count<quota;
 if not found then raise exception 'Voucher tidak valid, berakhir, atau kuota habis'; end if;
 if p_subtotal<v.min_purchase then raise exception 'Minimal pembelian voucher adalah %',v.min_purchase; end if;
 d:=case when v.discount_type='percent' then p_subtotal*(v.discount_value/100) else v.discount_value end;
 if v.max_discount is not null then d:=least(d,v.max_discount); end if;
 d:=least(greatest(d,0),p_subtotal);
 return jsonb_build_object('code',v.code,'discount',d,'total',p_subtotal-d);
end $$;

create or replace function public.create_order(p_customer jsonb,p_items jsonb,p_voucher_code text default null,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public,auth as $$
declare uid uuid:=auth.uid(); email text:=coalesce(auth.jwt()->>'email',''); oid uuid; ono text; j jsonb; it public.items%rowtype; iid uuid; q int; sub numeric:=0; disc numeric:=0; tot numeric:=0; vc text:=nullif(upper(trim(coalesce(p_voucher_code,''))),''); v public.vouchers%rowtype; need_g boolean:=false;
begin
 if uid is null then raise exception 'Silakan login terlebih dahulu'; end if;
 if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Keranjang kosong'; end if;
 if nullif(trim(p_customer->>'full_name'),'') is null or nullif(trim(p_customer->>'phone'),'') is null or nullif(trim(p_customer->>'address'),'') is null or nullif(trim(p_customer->>'city'),'') is null or nullif(trim(p_customer->>'identity_type'),'') is null or char_length(trim(coalesce(p_customer->>'identity_last4','')))<>4 or nullif(trim(p_customer->>'emergency_contact_name'),'') is null or nullif(trim(p_customer->>'emergency_contact_phone'),'') is null then raise exception 'Identitas belum lengkap'; end if;
 for j in select value from jsonb_array_elements(p_items) loop
  iid:=(j->>'item_id')::uuid; q:=(j->>'quantity')::int;
  select * into it from public.items where id=iid and is_active=true;
  if not found then raise exception 'Salah satu item tidak tersedia'; end if;
  if q<1 or q>99 then raise exception 'Jumlah item tidak valid'; end if;
  if it.type='product' and it.stock<q then raise exception 'Stok % tidak cukup',it.title; end if;
  if it.type='trip' and coalesce(it.quota,0)<q then raise exception 'Kuota % tidak cukup',it.title; end if;
  sub:=sub+(it.price*q); need_g:=need_g or it.requires_guarantee;
 end loop;
 if need_g and (nullif(trim(p_customer->>'guarantee_type'),'') is null or nullif(trim(p_customer->>'guarantee_notes'),'') is null) then raise exception 'Pesanan ini memerlukan jaminan'; end if;
 if vc is not null then
  select * into v from public.vouchers where code=vc and is_active=true and now() between starts_at and expires_at and used_count<quota;
  if not found then raise exception 'Voucher tidak valid atau kuota habis'; end if;
  if sub<v.min_purchase then raise exception 'Minimal pembelian voucher adalah %',v.min_purchase; end if;
  disc:=case when v.discount_type='percent' then sub*(v.discount_value/100) else v.discount_value end;
  if v.max_discount is not null then disc:=least(disc,v.max_discount); end if;
  disc:=least(greatest(disc,0),sub);
 end if;
 tot:=sub-disc; ono:='AOC-'||to_char(clock_timestamp(),'YYYYMMDD')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
 insert into public.orders(order_number,user_id,customer_name,customer_email,phone,address,city,postal_code,identity_type,identity_last4,emergency_contact_name,emergency_contact_phone,guarantee_type,guarantee_notes,customer_notes,voucher_code,subtotal,discount,total)
 values(ono,uid,trim(p_customer->>'full_name'),email,trim(p_customer->>'phone'),trim(p_customer->>'address'),trim(p_customer->>'city'),nullif(trim(p_customer->>'postal_code'),''),trim(p_customer->>'identity_type'),trim(p_customer->>'identity_last4'),trim(p_customer->>'emergency_contact_name'),trim(p_customer->>'emergency_contact_phone'),nullif(trim(p_customer->>'guarantee_type'),''),nullif(trim(p_customer->>'guarantee_notes'),''),nullif(trim(p_notes),''),vc,sub,disc,tot) returning id into oid;
 for j in select value from jsonb_array_elements(p_items) loop
  iid:=(j->>'item_id')::uuid; q:=(j->>'quantity')::int; select * into it from public.items where id=iid;
  insert into public.order_items(order_id,item_id,title_snapshot,item_type,price_snapshot,quantity,line_total,trip_date_snapshot) values(oid,it.id,it.title,it.type,it.price,q,it.price*q,it.trip_date);
 end loop;
 update public.profiles set full_name=trim(p_customer->>'full_name'),phone=trim(p_customer->>'phone'),address=trim(p_customer->>'address'),city=trim(p_customer->>'city'),postal_code=nullif(trim(p_customer->>'postal_code'),'') where id=uid;
 return jsonb_build_object('order_id',oid,'order_number',ono,'subtotal',sub,'discount',disc,'total',tot,'status','pending');
end $$;

create or replace function public.admin_update_order_status(p_order_id uuid,p_status text,p_admin_notes text default null)
returns void language plpgsql security definer set search_path=public as $$
declare o public.orders%rowtype; l public.order_items%rowtype; old_res boolean; new_res boolean;
begin
 if not public.is_admin() then raise exception 'Akses admin diperlukan'; end if;
 if p_status not in('pending','confirmed','paid','completed','cancelled') then raise exception 'Status tidak valid'; end if;
 select * into o from public.orders where id=p_order_id for update; if not found then raise exception 'Pesanan tidak ditemukan'; end if;
 old_res:=o.status in('confirmed','paid','completed'); new_res:=p_status in('confirmed','paid','completed');
 if not old_res and new_res then
  for l in select * from public.order_items where order_id=p_order_id loop
   if l.item_type='product' then update public.items set stock=stock-l.quantity where id=l.item_id and stock>=l.quantity; else update public.items set quota=quota-l.quantity where id=l.item_id and coalesce(quota,0)>=l.quantity; end if;
   if not found then raise exception 'Stok/kuota % tidak cukup',l.title_snapshot; end if;
  end loop;
  if o.voucher_code is not null then update public.vouchers set used_count=used_count+1 where code=o.voucher_code and used_count<quota; if not found then raise exception 'Kuota voucher habis'; end if; end if;
 elsif old_res and p_status='cancelled' then
  for l in select * from public.order_items where order_id=p_order_id loop
   if l.item_type='product' then update public.items set stock=stock+l.quantity where id=l.item_id; else update public.items set quota=coalesce(quota,0)+l.quantity where id=l.item_id; end if;
  end loop;
  if o.voucher_code is not null then update public.vouchers set used_count=greatest(used_count-1,0) where code=o.voucher_code; end if;
 end if;
 update public.orders set status=p_status,admin_notes=nullif(trim(p_admin_notes),''),updated_at=now() where id=p_order_id;
end $$;

revoke all on function public.preview_voucher(text,numeric) from public;
revoke all on function public.create_order(jsonb,jsonb,text,text) from public;
revoke all on function public.admin_update_order_status(uuid,text,text) from public;
grant execute on function public.preview_voucher(text,numeric) to authenticated;
grant execute on function public.create_order(jsonb,jsonb,text,text) to authenticated;
grant execute on function public.admin_update_order_status(uuid,text,text) to authenticated;
