-- PROFIL SAYA
-- Jalankan hanya bila halaman Profil mendapat error RLS/permission.

alter table public.profiles enable row level security;

drop policy if exists "profiles own account read"
on public.profiles;

create policy "profiles own account read"
on public.profiles
for select
to authenticated
using (
  id = auth.uid()
  or public.is_admin()
);

drop policy if exists "profiles own account update"
on public.profiles;

create policy "profiles own account update"
on public.profiles
for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

grant select, update on public.profiles to authenticated;

notify pgrst, 'reload schema';
