create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  type text not null check (type in ('product','trip')),
  description text not null default '',
  image_url text not null default '',
  price numeric(14,2) not null default 0 check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  location text,
  trip_date date,
  quota integer check (quota is null or quota >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.ratings (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  score integer not null check (score between 1 and 5),
  created_at timestamptz not null default now(),
  unique(item_id, user_id)
);

create table if not exists public.vouchers (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('percent','fixed')),
  discount_value numeric(14,2) not null check (discount_value > 0),
  min_purchase numeric(14,2) not null default 0,
  max_discount numeric(14,2),
  quota integer not null default 1 check (quota >= 0),
  used_count integer not null default 0 check (used_count >= 0),
  starts_at timestamptz not null,
  expires_at timestamptz not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles(id) values(new.id);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.items enable row level security;
alter table public.ratings enable row level security;
alter table public.vouchers enable row level security;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read"
on public.profiles for select
using (id = auth.uid() or public.is_admin());

drop policy if exists "items public read active" on public.items;
create policy "items public read active"
on public.items for select
using (is_active or public.is_admin());

drop policy if exists "items admin insert" on public.items;
create policy "items admin insert"
on public.items for insert
with check (public.is_admin());

drop policy if exists "items admin update" on public.items;
create policy "items admin update"
on public.items for update
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "items admin delete" on public.items;
create policy "items admin delete"
on public.items for delete
using (public.is_admin());

drop policy if exists "ratings public read" on public.ratings;
create policy "ratings public read"
on public.ratings for select
using (true);

drop policy if exists "ratings own insert" on public.ratings;
create policy "ratings own insert"
on public.ratings for insert
with check (user_id = auth.uid());

drop policy if exists "ratings own update" on public.ratings;
create policy "ratings own update"
on public.ratings for update
using (user_id = auth.uid())
with check (user_id = auth.uid());

drop policy if exists "vouchers active read" on public.vouchers;
create policy "vouchers active read"
on public.vouchers for select
using (is_active or public.is_admin());

drop policy if exists "vouchers admin insert" on public.vouchers;
create policy "vouchers admin insert"
on public.vouchers for insert
with check (public.is_admin());

drop policy if exists "vouchers admin update" on public.vouchers;
create policy "vouchers admin update"
on public.vouchers for update
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "vouchers admin delete" on public.vouchers;
create policy "vouchers admin delete"
on public.vouchers for delete
using (public.is_admin());

insert into public.items (
  title, slug, type, description, image_url,
  price, stock, location, trip_date, quota
)
values
(
  'Open Trip Dieng',
  'open-trip-dieng',
  'trip',
  'Paket perjalanan Dieng 2 hari 1 malam termasuk transportasi lokal, penginapan, tiket destinasi, dan dokumentasi.',
  'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  750000, 0, 'Dieng, Jawa Tengah', current_date + 30, 20
),
(
  'Dry Bag 20L',
  'dry-bag-20l',
  'product',
  'Dry bag tahan air untuk menjaga barang tetap aman saat kegiatan pantai, rafting, dan hiking.',
  'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1200&q=80',
  185000, 25, null, null, null
)
on conflict (slug) do nothing;

-- Setelah membuat akun melalui login.html, jadikan admin:
-- update public.profiles
-- set role = 'admin'
-- where id = (
--   select id from auth.users
--   where email = 'admin@email.com'
-- );
