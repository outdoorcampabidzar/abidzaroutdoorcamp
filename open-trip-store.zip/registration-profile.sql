-- REGISTRASI PROFIL LENGKAP ABIDZAROUTDOORCAMP
-- Jalankan seluruh file melalui Supabase SQL Editor.

alter table public.profiles
  add column if not exists phone text;

alter table public.profiles
  add column if not exists address text;

alter table public.profiles
  add column if not exists city text;

alter table public.profiles
  add column if not exists postal_code text;

-- Menyimpan metadata registrasi ketika pengguna baru dibuat.
create or replace function public.sync_new_registration_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (
    id,
    full_name,
    phone,
    address,
    city,
    postal_code,
    role
  )
  values (
    new.id,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'full_name', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'phone', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'address', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'city', '')), ''),
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'postal_code', '')), ''),
    'user'
  )
  on conflict (id)
  do update set
    full_name = coalesce(
      excluded.full_name,
      public.profiles.full_name
    ),
    phone = coalesce(
      excluded.phone,
      public.profiles.phone
    ),
    address = coalesce(
      excluded.address,
      public.profiles.address
    ),
    city = coalesce(
      excluded.city,
      public.profiles.city
    ),
    postal_code = coalesce(
      excluded.postal_code,
      public.profiles.postal_code
    );

  return new;
end;
$$;

-- Nama diawali zz agar dijalankan setelah trigger profil umum yang mungkin sudah ada.
drop trigger if exists zz_sync_registration_profile
on auth.users;

create trigger zz_sync_registration_profile
after insert on auth.users
for each row
execute function public.sync_new_registration_profile();

-- Digunakan bila Supabase langsung memberikan session setelah registrasi.
create or replace function public.complete_my_profile(
  p_profile jsonb
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'Sesi login tidak ditemukan';
  end if;

  insert into public.profiles (
    id,
    full_name,
    phone,
    address,
    city,
    postal_code,
    role
  )
  values (
    v_user_id,
    nullif(trim(coalesce(p_profile ->> 'full_name', '')), ''),
    nullif(trim(coalesce(p_profile ->> 'phone', '')), ''),
    nullif(trim(coalesce(p_profile ->> 'address', '')), ''),
    nullif(trim(coalesce(p_profile ->> 'city', '')), ''),
    nullif(trim(coalesce(p_profile ->> 'postal_code', '')), ''),
    'user'
  )
  on conflict (id)
  do update set
    full_name = coalesce(
      excluded.full_name,
      public.profiles.full_name
    ),
    phone = coalesce(
      excluded.phone,
      public.profiles.phone
    ),
    address = coalesce(
      excluded.address,
      public.profiles.address
    ),
    city = coalesce(
      excluded.city,
      public.profiles.city
    ),
    postal_code = coalesce(
      excluded.postal_code,
      public.profiles.postal_code
    );
end;
$$;

revoke all on function public.complete_my_profile(jsonb)
from public;

grant execute on function public.complete_my_profile(jsonb)
to authenticated;

alter table public.profiles enable row level security;

drop policy if exists "profiles own registration read"
on public.profiles;

create policy "profiles own registration read"
on public.profiles
for select
to authenticated
using (
  id = auth.uid()
  or public.is_admin()
);

drop policy if exists "profiles own registration update"
on public.profiles;

create policy "profiles own registration update"
on public.profiles
for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

grant select, update on public.profiles to authenticated;

notify pgrst, 'reload schema';

select
  routine_name
from information_schema.routines
where routine_schema = 'public'
  and routine_name in (
    'sync_new_registration_profile',
    'complete_my_profile'
  )
order by routine_name;
