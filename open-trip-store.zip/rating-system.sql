-- SISTEM RATING 1–5 BINTANG
-- Jalankan seluruh file ini melalui Supabase SQL Editor.

create extension if not exists "pgcrypto";

create table if not exists public.ratings (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  score integer not null check (score between 1 and 5),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.ratings
  add column if not exists updated_at timestamptz not null default now();

create unique index if not exists ratings_item_user_unique_idx
on public.ratings(item_id, user_id);

create index if not exists ratings_item_id_idx
on public.ratings(item_id);

alter table public.ratings enable row level security;

-- Data mentah rating tidak dibuka ke browser.
drop policy if exists "ratings public read" on public.ratings;
drop policy if exists "ratings own read" on public.ratings;
drop policy if exists "ratings own insert" on public.ratings;
drop policy if exists "ratings own update" on public.ratings;

revoke all on table public.ratings from anon, authenticated;

-- Ringkasan rating untuk kartu katalog.
create or replace function public.get_rating_summaries(
  p_item_ids uuid[] default null
)
returns table (
  item_id uuid,
  rating_average numeric,
  rating_count bigint
)
language sql
stable
security definer
set search_path = public
as $$
  select
    r.item_id,
    round(avg(r.score)::numeric, 1) as rating_average,
    count(*) as rating_count
  from public.ratings r
  where p_item_ids is null
     or r.item_id = any(p_item_ids)
  group by r.item_id;
$$;

-- Ringkasan satu item beserta rating milik pengguna yang login.
create or replace function public.get_item_rating(
  p_item_id uuid
)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_average numeric := 0;
  v_count bigint := 0;
  v_my_score integer := 0;
begin
  if not exists (
    select 1
    from public.items
    where id = p_item_id
  ) then
    raise exception 'Item tidak ditemukan';
  end if;

  select
    coalesce(round(avg(score)::numeric, 1), 0),
    count(*)
  into v_average, v_count
  from public.ratings
  where item_id = p_item_id;

  if auth.uid() is not null then
    select coalesce(score, 0)
    into v_my_score
    from public.ratings
    where item_id = p_item_id
      and user_id = auth.uid();

    v_my_score := coalesce(v_my_score, 0);
  end if;

  return jsonb_build_object(
    'item_id', p_item_id,
    'rating_average', v_average,
    'rating_count', v_count,
    'my_score', v_my_score
  );
end;
$$;

-- Menambah atau mengubah rating pengguna.
create or replace function public.submit_item_rating(
  p_item_id uuid,
  p_score integer
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_average numeric := 0;
  v_count bigint := 0;
begin
  if auth.uid() is null then
    raise exception 'Silakan login untuk memberikan rating';
  end if;

  if p_score < 1 or p_score > 5 then
    raise exception 'Rating harus antara 1 sampai 5';
  end if;

  if not exists (
    select 1
    from public.items
    where id = p_item_id
      and is_active = true
  ) then
    raise exception 'Item tidak ditemukan atau sudah tidak aktif';
  end if;

  insert into public.ratings (
    item_id,
    user_id,
    score,
    updated_at
  )
  values (
    p_item_id,
    auth.uid(),
    p_score,
    now()
  )
  on conflict (item_id, user_id)
  do update set
    score = excluded.score,
    updated_at = now();

  select
    coalesce(round(avg(score)::numeric, 1), 0),
    count(*)
  into v_average, v_count
  from public.ratings
  where item_id = p_item_id;

  return jsonb_build_object(
    'item_id', p_item_id,
    'rating_average', v_average,
    'rating_count', v_count,
    'my_score', p_score
  );
end;
$$;

revoke all on function public.get_rating_summaries(uuid[]) from public;
revoke all on function public.get_item_rating(uuid) from public;
revoke all on function public.submit_item_rating(uuid, integer) from public;

grant execute on function public.get_rating_summaries(uuid[])
to anon, authenticated;

grant execute on function public.get_item_rating(uuid)
to anon, authenticated;

grant execute on function public.submit_item_rating(uuid, integer)
to authenticated;
